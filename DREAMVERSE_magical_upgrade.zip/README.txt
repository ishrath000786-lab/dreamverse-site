DREAMVERSE Magical Starter

1. Open index.html to preview the website.
2. To publish it, create a public repository on GitHub and upload index.html, manifest.json, sw.js, and icon.svg.
3. In repository Settings > Pages, choose Deploy from a branch, select main and /(root), and save.
4. Wait for GitHub Pages to publish the site. Open the published address in Chrome.
5. On Android Chrome, use the three-dot menu and look for Add to Home screen or Install app.

This is a front-end demo. The AI Assistant is a placeholder and there is no online login system. Goals are stored locally in the browser. Never publish passwords or secret API keys.
